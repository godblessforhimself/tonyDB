use orderDB;
select * from customer where id>0;
exit
