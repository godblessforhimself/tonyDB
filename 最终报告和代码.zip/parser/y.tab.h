/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOKEN_EOF = 258,
     TOKEN_CREATE = 259,
     TOKEN_DATABASE = 260,
     TOKEN_DATABASES = 261,
     TOKEN_DROP = 262,
     TOKEN_USE = 263,
     TOKEN_SHOW = 264,
     TOKEN_TABLE = 265,
     TOKEN_TABLES = 266,
     TOKEN_NOT = 267,
     TOKEN_NULL = 268,
     TOKEN_KEY = 269,
     TOKEN_PRIMARY = 270,
     TOKEN_INTO = 271,
     TOKEN_INSERT = 272,
     TOKEN_VALUES = 273,
     TOKEN_DELETE = 274,
     TOKEN_FROM = 275,
     TOKEN_WHERE = 276,
     TOKEN_UPDATE = 277,
     TOKEN_SET = 278,
     TOKEN_SELECT = 279,
     TOKEN_IS = 280,
     TOKEN_INT = 281,
     TOKEN_VARCHAR = 282,
     TOKEN_DESC = 283,
     TOKEN_INDEX = 284,
     TOKEN_AND = 285,
     TOKEN_DATE = 286,
     TOKEN_FLOAT = 287,
     TOKEN_FOREIGN = 288,
     TOKEN_REFERENCES = 289,
     OP_LT = 290,
     OP_LE = 291,
     OP_GT = 292,
     OP_GE = 293,
     OP_EQ = 294,
     OP_NE = 295,
     TOKEN_EXIT = 296,
     TOKEN_STRING_IDENTIFIER = 297,
     SYS_COMMAND = 298,
     VALUE_STRING = 299,
     VALUE_INT = 300,
     VALUE_FLOAT = 301
   };
#endif
/* Tokens.  */
#define TOKEN_EOF 258
#define TOKEN_CREATE 259
#define TOKEN_DATABASE 260
#define TOKEN_DATABASES 261
#define TOKEN_DROP 262
#define TOKEN_USE 263
#define TOKEN_SHOW 264
#define TOKEN_TABLE 265
#define TOKEN_TABLES 266
#define TOKEN_NOT 267
#define TOKEN_NULL 268
#define TOKEN_KEY 269
#define TOKEN_PRIMARY 270
#define TOKEN_INTO 271
#define TOKEN_INSERT 272
#define TOKEN_VALUES 273
#define TOKEN_DELETE 274
#define TOKEN_FROM 275
#define TOKEN_WHERE 276
#define TOKEN_UPDATE 277
#define TOKEN_SET 278
#define TOKEN_SELECT 279
#define TOKEN_IS 280
#define TOKEN_INT 281
#define TOKEN_VARCHAR 282
#define TOKEN_DESC 283
#define TOKEN_INDEX 284
#define TOKEN_AND 285
#define TOKEN_DATE 286
#define TOKEN_FLOAT 287
#define TOKEN_FOREIGN 288
#define TOKEN_REFERENCES 289
#define OP_LT 290
#define OP_LE 291
#define OP_GT 292
#define OP_GE 293
#define OP_EQ 294
#define OP_NE 295
#define TOKEN_EXIT 296
#define TOKEN_STRING_IDENTIFIER 297
#define SYS_COMMAND 298
#define VALUE_STRING 299
#define VALUE_INT 300
#define VALUE_FLOAT 301




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

