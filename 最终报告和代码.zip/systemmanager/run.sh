
g++ -std=c++11 dbcreate.cpp -o dbcreate
