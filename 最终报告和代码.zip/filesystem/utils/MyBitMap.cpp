#include "MyBitMap.h"
unsigned char MyBitMap::h[61] = {0};
bool MyBitMap::inited = false;