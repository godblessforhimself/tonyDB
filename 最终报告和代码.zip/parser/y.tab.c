/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOKEN_EOF = 258,
     TOKEN_CREATE = 259,
     TOKEN_DATABASE = 260,
     TOKEN_DATABASES = 261,
     TOKEN_DROP = 262,
     TOKEN_USE = 263,
     TOKEN_SHOW = 264,
     TOKEN_TABLE = 265,
     TOKEN_TABLES = 266,
     TOKEN_NOT = 267,
     TOKEN_NULL = 268,
     TOKEN_KEY = 269,
     TOKEN_PRIMARY = 270,
     TOKEN_INTO = 271,
     TOKEN_INSERT = 272,
     TOKEN_VALUES = 273,
     TOKEN_DELETE = 274,
     TOKEN_FROM = 275,
     TOKEN_WHERE = 276,
     TOKEN_UPDATE = 277,
     TOKEN_SET = 278,
     TOKEN_SELECT = 279,
     TOKEN_IS = 280,
     TOKEN_INT = 281,
     TOKEN_VARCHAR = 282,
     TOKEN_DESC = 283,
     TOKEN_INDEX = 284,
     TOKEN_AND = 285,
     TOKEN_DATE = 286,
     TOKEN_FLOAT = 287,
     TOKEN_FOREIGN = 288,
     TOKEN_REFERENCES = 289,
     OP_LT = 290,
     OP_LE = 291,
     OP_GT = 292,
     OP_GE = 293,
     OP_EQ = 294,
     OP_NE = 295,
     TOKEN_EXIT = 296,
     TOKEN_STRING_IDENTIFIER = 297,
     SYS_COMMAND = 298,
     VALUE_STRING = 299,
     VALUE_INT = 300,
     VALUE_FLOAT = 301
   };
#endif
/* Tokens.  */
#define TOKEN_EOF 258
#define TOKEN_CREATE 259
#define TOKEN_DATABASE 260
#define TOKEN_DATABASES 261
#define TOKEN_DROP 262
#define TOKEN_USE 263
#define TOKEN_SHOW 264
#define TOKEN_TABLE 265
#define TOKEN_TABLES 266
#define TOKEN_NOT 267
#define TOKEN_NULL 268
#define TOKEN_KEY 269
#define TOKEN_PRIMARY 270
#define TOKEN_INTO 271
#define TOKEN_INSERT 272
#define TOKEN_VALUES 273
#define TOKEN_DELETE 274
#define TOKEN_FROM 275
#define TOKEN_WHERE 276
#define TOKEN_UPDATE 277
#define TOKEN_SET 278
#define TOKEN_SELECT 279
#define TOKEN_IS 280
#define TOKEN_INT 281
#define TOKEN_VARCHAR 282
#define TOKEN_DESC 283
#define TOKEN_INDEX 284
#define TOKEN_AND 285
#define TOKEN_DATE 286
#define TOKEN_FLOAT 287
#define TOKEN_FOREIGN 288
#define TOKEN_REFERENCES 289
#define OP_LT 290
#define OP_LE 291
#define OP_GT 292
#define OP_GE 293
#define OP_EQ 294
#define OP_NE 295
#define TOKEN_EXIT 296
#define TOKEN_STRING_IDENTIFIER 297
#define SYS_COMMAND 298
#define VALUE_STRING 299
#define VALUE_INT 300
#define VALUE_FLOAT 301




/* Copy the first part of user declarations.  */
#line 1 "parser/parser.y"

    #include "parser.h"
    using namespace std;
    extern "C" {
        void yyerror(char *);
        int yyparse(void);
        int yywrap(void);
        extern int yylex(void);
    }
    int exit_flag = 0;
    int attrcount = 0, indexcount = 0, insertcount = 0;
    RelationEntry tbentry;
    AttributeEntry *attrentry = NULL;
    RecordHandle *fileHandle = NULL;
    IX_IndexHandle *indexHandles = NULL;
#ifndef yyrestart
    void yyrestart(FILE*);
#endif


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 218 "parser/y.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  42
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   144

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  53
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  26
/* YYNRULES -- Number of rules.  */
#define YYNRULES  69
/* YYNRULES -- Number of states.  */
#define YYNSTATES  157

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   301

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      48,    49,    51,     2,    50,     2,    52,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    47,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint8 yyprhs[] =
{
       0,     0,     3,     5,     7,     9,    11,    14,    17,    20,
      23,    26,    30,    34,    37,    40,    44,    51,    54,    56,
      62,    69,    76,    84,    90,    97,   104,   106,   110,   113,
     118,   124,   135,   137,   139,   141,   145,   147,   151,   153,
     157,   162,   167,   169,   171,   173,   175,   177,   179,   181,
     185,   189,   195,   197,   201,   205,   209,   214,   216,   220,
     222,   224,   226,   228,   230,   232,   234,   236,   238,   240
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      54,     0,    -1,    55,    -1,    43,    -1,    41,    -1,     3,
      -1,    56,    47,    -1,    57,    47,    -1,    58,    47,    -1,
      60,    47,    -1,     9,     6,    -1,     4,     5,    76,    -1,
       7,     5,    76,    -1,     8,    76,    -1,     9,    11,    -1,
       7,    10,    77,    -1,     4,    10,    77,    48,    61,    49,
      -1,    28,    77,    -1,    59,    -1,    19,    20,    77,    21,
      71,    -1,    22,    77,    23,    70,    21,    71,    -1,    24,
      63,    20,    65,    21,    71,    -1,    17,    16,    77,    18,
      48,    69,    49,    -1,    59,    50,    48,    69,    49,    -1,
       4,    29,    77,    48,    78,    49,    -1,     7,    29,    77,
      48,    78,    49,    -1,    62,    -1,    61,    50,    62,    -1,
      78,    67,    -1,    78,    67,    12,    13,    -1,    15,    14,
      48,    66,    49,    -1,    33,    14,    48,    78,    49,    34,
      77,    48,    78,    49,    -1,    51,    -1,    64,    -1,    73,
      -1,    64,    50,    73,    -1,    77,    -1,    65,    50,    77,
      -1,    78,    -1,    66,    50,    78,    -1,    26,    48,    45,
      49,    -1,    27,    48,    45,    49,    -1,    31,    -1,    32,
      -1,    45,    -1,    44,    -1,    46,    -1,    13,    -1,    68,
      -1,    69,    50,    68,    -1,    78,    39,    68,    -1,    70,
      50,    78,    39,    68,    -1,    72,    -1,    71,    30,    72,
      -1,    73,    75,    74,    -1,    73,    25,    13,    -1,    73,
      25,    12,    13,    -1,    78,    -1,    77,    52,    78,    -1,
      73,    -1,    68,    -1,    35,    -1,    36,    -1,    37,    -1,
      38,    -1,    39,    -1,    40,    -1,    42,    -1,    42,    -1,
      42,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    67,    67,    72,    79,    84,    90,    91,    92,    93,
      95,   101,   111,   120,   129,   137,   144,   154,   161,   173,
     181,   190,   202,   281,   298,   305,   313,   319,   326,   333,
     340,   345,   354,   360,   367,   373,   381,   387,   395,   401,
     409,   415,   421,   427,   434,   440,   446,   452,   460,   466,
     475,   482,   491,   497,   505,   511,   517,   524,   530,   537,
     543,   550,   554,   558,   562,   566,   570,   575,   577,   579
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOKEN_EOF", "TOKEN_CREATE",
  "TOKEN_DATABASE", "TOKEN_DATABASES", "TOKEN_DROP", "TOKEN_USE",
  "TOKEN_SHOW", "TOKEN_TABLE", "TOKEN_TABLES", "TOKEN_NOT", "TOKEN_NULL",
  "TOKEN_KEY", "TOKEN_PRIMARY", "TOKEN_INTO", "TOKEN_INSERT",
  "TOKEN_VALUES", "TOKEN_DELETE", "TOKEN_FROM", "TOKEN_WHERE",
  "TOKEN_UPDATE", "TOKEN_SET", "TOKEN_SELECT", "TOKEN_IS", "TOKEN_INT",
  "TOKEN_VARCHAR", "TOKEN_DESC", "TOKEN_INDEX", "TOKEN_AND", "TOKEN_DATE",
  "TOKEN_FLOAT", "TOKEN_FOREIGN", "TOKEN_REFERENCES", "OP_LT", "OP_LE",
  "OP_GT", "OP_GE", "OP_EQ", "OP_NE", "TOKEN_EXIT",
  "TOKEN_STRING_IDENTIFIER", "SYS_COMMAND", "VALUE_STRING", "VALUE_INT",
  "VALUE_FLOAT", "';'", "'('", "')'", "','", "'*'", "'.'", "$accept",
  "program", "stmt", "sysStmt", "dbStmt", "tbStmt", "insert", "idxStmt",
  "fieldList", "field", "selector", "colList", "tableList", "columnList",
  "type", "value", "valueList", "setClause", "whereClause", "condition",
  "col", "expr", "op", "dbName", "tbName", "colName", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,    59,    40,    41,
      44,    42,    46
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    53,    54,    54,    54,    54,    55,    55,    55,    55,
      56,    57,    57,    57,    57,    58,    58,    58,    58,    58,
      58,    58,    59,    59,    60,    60,    61,    61,    62,    62,
      62,    62,    63,    63,    64,    64,    65,    65,    66,    66,
      67,    67,    67,    67,    68,    68,    68,    68,    69,    69,
      70,    70,    71,    71,    72,    72,    72,    73,    73,    74,
      74,    75,    75,    75,    75,    75,    75,    76,    77,    78
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     2,     2,     2,     2,
       2,     3,     3,     2,     2,     3,     6,     2,     1,     5,
       6,     6,     7,     5,     6,     6,     1,     3,     2,     4,
       5,    10,     1,     1,     1,     3,     1,     3,     1,     3,
       4,     4,     1,     1,     1,     1,     1,     1,     1,     3,
       3,     5,     1,     3,     3,     3,     4,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     5,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     4,     3,     0,     2,     0,     0,     0,    18,     0,
       0,     0,     0,     0,     0,     0,    67,    13,    10,    14,
       0,     0,    68,     0,    69,    32,     0,    33,    34,     0,
      57,    17,     1,     6,     7,     8,     0,     9,    11,     0,
       0,    12,    15,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    69,     0,     0,     0,
      36,    35,    58,    47,    45,    44,    46,    48,     0,     0,
       0,     0,    26,     0,     0,     0,     0,    19,    52,     0,
       0,     0,     0,     0,     0,    23,     0,     0,     0,    16,
       0,     0,     0,    42,    43,    28,    24,    25,     0,     0,
       0,    61,    62,    63,    64,    65,    66,     0,    20,     0,
      50,    21,    37,    49,     0,     0,    27,     0,     0,     0,
      22,    53,     0,    55,    60,    59,    54,     0,     0,    38,
       0,     0,     0,    29,    56,    51,    30,     0,     0,    40,
      41,    39,     0,     0,     0,     0,    31
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    13,    14,    15,    16,    17,    18,    19,    81,    82,
      36,    37,    69,   138,   105,    77,    78,    67,    87,    88,
      89,   136,   117,    27,    39,    40
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -88
static const yytype_int8 yypact[] =
{
      34,   -88,    58,    61,   -24,    20,    11,    37,    13,   -30,
      13,   -88,   -88,    65,   -88,   -12,    33,    41,    26,    42,
     -24,    13,    13,   -24,    13,    13,   -88,   -88,   -88,   -88,
      13,    13,   -88,    71,    43,   -88,    73,    46,   -88,    45,
     -88,   -88,   -88,   -88,   -88,   -88,    50,   -88,   -88,    52,
      59,   -88,   -88,    60,    91,    89,    72,    13,    74,    72,
      15,    39,    72,    72,    64,    74,   -88,   -11,    76,   -10,
     -88,   -88,   -88,   -88,   -88,   -88,   -88,   -88,   -16,    99,
     103,    24,   -88,    -7,    69,    75,    15,    90,   -88,    66,
      74,    72,    15,    74,    13,   -88,    15,    77,    78,   -88,
      39,    79,    80,   -88,   -88,   107,   -88,   -88,    29,    74,
      70,   -88,   -88,   -88,   -88,   -88,   -88,     2,    90,    82,
     -88,    90,   -88,   -88,    72,    72,   -88,    84,    85,   109,
     -88,   -88,   110,   -88,   -88,   -88,   -88,    15,    35,   -88,
      83,    86,    87,   -88,   -88,   -88,   -88,    72,    97,   -88,
     -88,   -88,    13,    92,    72,    88,   -88
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int8 yypgoto[] =
{
     -88,   -88,   -88,   -88,   -88,   -88,   -88,   -88,   -88,    38,
     -88,   -88,   -88,   -88,   -88,   -87,    47,   -88,   -61,    25,
      -6,   -88,   -88,    44,    -8,   -55
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -69
static const yytype_int16 yytable[] =
{
      33,    68,    41,    38,    72,   120,    83,    84,    85,   123,
      90,    93,    34,    49,    50,    73,    52,    53,    26,   101,
     102,    35,    54,    55,   103,   104,    28,    30,    73,   118,
     134,    29,   121,    95,    96,    43,   119,     1,     2,    91,
      94,     3,     4,     5,    34,    83,    74,    75,    76,    70,
     145,     6,    71,     7,    79,    32,     8,    31,     9,    74,
      75,    76,    10,    20,    48,    42,    23,    51,    21,   139,
     140,    24,    80,    99,   100,    11,    46,    12,   130,    96,
      44,    66,   132,   133,   146,   147,   122,    22,    45,    47,
      25,   110,   151,    57,    56,   -68,    58,    59,    60,   155,
      61,   111,   112,   113,   114,   115,   116,    62,    63,    64,
      65,   135,    86,    97,    66,    92,    34,    98,   106,   129,
     109,   137,   143,   144,   107,   124,   125,   127,   128,   141,
     142,   152,   148,   108,   131,   149,   150,   156,   126,     0,
     154,     0,     0,     0,   153
};

static const yytype_int16 yycheck[] =
{
       8,    56,    10,     9,    59,    92,    61,    62,    63,    96,
      21,    21,    42,    21,    22,    13,    24,    25,    42,    26,
      27,    51,    30,    31,    31,    32,     6,    16,    13,    90,
     117,    11,    93,    49,    50,    47,    91,     3,     4,    50,
      50,     7,     8,     9,    42,   100,    44,    45,    46,    57,
     137,    17,    58,    19,    15,    42,    22,    20,    24,    44,
      45,    46,    28,     5,    20,     0,     5,    23,    10,   124,
     125,    10,    33,    49,    50,    41,    50,    43,    49,    50,
      47,    42,    12,    13,    49,    50,    94,    29,    47,    47,
      29,    25,   147,    20,    23,    52,    50,    52,    48,   154,
      48,    35,    36,    37,    38,    39,    40,    48,    48,    18,
      21,   117,    48,    14,    42,    39,    42,    14,    49,    12,
      30,    39,    13,    13,    49,    48,    48,    48,    48,    45,
      45,    34,    49,    86,   109,    49,    49,    49,   100,    -1,
      48,    -1,    -1,    -1,   152
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     4,     7,     8,     9,    17,    19,    22,    24,
      28,    41,    43,    54,    55,    56,    57,    58,    59,    60,
       5,    10,    29,     5,    10,    29,    42,    76,     6,    11,
      16,    20,    42,    77,    42,    51,    63,    64,    73,    77,
      78,    77,     0,    47,    47,    47,    50,    47,    76,    77,
      77,    76,    77,    77,    77,    77,    23,    20,    50,    52,
      48,    48,    48,    48,    18,    21,    42,    70,    78,    65,
      77,    73,    78,    13,    44,    45,    46,    68,    69,    15,
      33,    61,    62,    78,    78,    78,    48,    71,    72,    73,
      21,    50,    39,    21,    50,    49,    50,    14,    14,    49,
      50,    26,    27,    31,    32,    67,    49,    49,    69,    30,
      25,    35,    36,    37,    38,    39,    40,    75,    71,    78,
      68,    71,    77,    68,    48,    48,    62,    48,    48,    12,
      49,    72,    12,    13,    68,    73,    74,    39,    66,    78,
      78,    45,    45,    13,    13,    68,    49,    50,    49,    49,
      49,    78,    34,    77,    48,    78,    49
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 68 "parser/parser.y"
    {
            reset_ptr();
            YYACCEPT;
        }
    break;

  case 3:
#line 73 "parser/parser.y"
    {
            // !执行系统命令
            reset_ptr();
            system((yyvsp[(1) - (1)].sval));
            YYACCEPT;
        }
    break;

  case 4:
#line 80 "parser/parser.y"
    {
            exit_flag = 1;
            YYACCEPT;
        }
    break;

  case 5:
#line 85 "parser/parser.y"
    {
            //exit_flag = 1;
            YYACCEPT;
        }
    break;

  case 10:
#line 96 "parser/parser.y"
    {
            // show databases
            printf("未实现show databases\n");
        }
    break;

  case 11:
#line 102 "parser/parser.y"
    {
            // 创建数据库 create database dbname
            if (gl_systemManager->createDb((yyvsp[(3) - (3)].sval)) != 0) {
                printf("create database %s failed!\n", (yyvsp[(3) - (3)].sval));
            } else {
                printf("create database %s success!\n", (yyvsp[(3) - (3)].sval));
                gl_bufPageManager->close();
            }
        }
    break;

  case 12:
#line 112 "parser/parser.y"
    {
            // 删除数据库 drop database dbname
            if (gl_systemManager->dropDb((yyvsp[(3) - (3)].sval)) != 0) {
                printf("drop database %s failed!\n", (yyvsp[(3) - (3)].sval));
            } else {
                printf("drop database %s success!\n", (yyvsp[(3) - (3)].sval));
            }
        }
    break;

  case 13:
#line 121 "parser/parser.y"
    {
            // 切换数据库 use dbname
            if (gl_systemManager->openDb((yyvsp[(2) - (2)].sval)) != 0) {
                printf("use database %s failed!\n", (yyvsp[(2) - (2)].sval));
            } else {
                printf("use database %s success!\n", (yyvsp[(2) - (2)].sval));
            }
        }
    break;

  case 14:
#line 130 "parser/parser.y"
    {
            // 显示当前数据库的数据表 show tables;
            if (gl_systemManager->showTables() != 0) {
                printf("show tables error!\n");
            }
        }
    break;

  case 15:
#line 138 "parser/parser.y"
    {
            // 删除当前数据库的表 drop table tbName
            if (gl_systemManager->dropTable((yyvsp[(3) - (3)].sval)) != 0) {
                printf("drop table error!\n");
            }
        }
    break;

  case 16:
#line 145 "parser/parser.y"
    {
            // 在当前数据库创建表 create Table tbName fieldList
            // $5->print(cout);
            if (gl_systemManager->createTable((yyvsp[(3) - (6)].sval), (yyvsp[(5) - (6)].pnode)) != 0) {
                printf("create table error!\n");
            } else {
                cout << "创建表" << (yyvsp[(3) - (6)].sval) << "成功\n";
            }
        }
    break;

  case 17:
#line 155 "parser/parser.y"
    {
            // 显示表的详细信息 desc tbName
            if (gl_systemManager->printTable((yyvsp[(2) - (2)].sval), cout) != 0) {
                printf("print %s failed!\n", (yyvsp[(2) - (2)].sval));
            }
        }
    break;

  case 18:
#line 162 "parser/parser.y"
    {
            // 释放
            if (attrentry != NULL) 
                delete[] attrentry;
            if (fileHandle != NULL)
                delete fileHandle;
            if (indexHandles != NULL)
                delete[] indexHandles;
            cout << "插入" << insertcount << "条记录\n";
            cout << "总共用时" << tickTock.tock() * 1000 << "ms\n";
        }
    break;

  case 19:
#line 174 "parser/parser.y"
    {
            // 删除表中数据 delete from tbName where []
            if (gl_qlManager->Delete((yyvsp[(3) - (5)].sval), (yyvsp[(5) - (5)].pnode)) != 0) {
                cout << "delete error!\n";
                // todo: 错误信息
            }
        }
    break;

  case 20:
#line 182 "parser/parser.y"
    {
            // 更新表中数据 update tbName set [] where []
            if (gl_qlManager->Update((yyvsp[(2) - (6)].sval), (yyvsp[(4) - (6)].pnode), (yyvsp[(6) - (6)].pnode)) != 0) {
                cout << "update error!\n";
                // todo: 错误信息
            }
            cout << "更新完成\n";
        }
    break;

  case 21:
#line 191 "parser/parser.y"
    {
            // 选择表中数据 select [] from [] where []
            tickTock.tick();
            if (gl_qlManager->Select((yyvsp[(2) - (6)].pnode), (yyvsp[(4) - (6)].pnode), (yyvsp[(6) - (6)].pnode)) != 0) {
                cout << "select error!\n";
                // todo: 错误信息
            }
            double second = tickTock.tock();
            cout << "select使用" << second * 1000 << "ms\n";
        }
    break;

  case 22:
#line 203 "parser/parser.y"
    {
            insertcount=0;
            // 创建
            RecordScan tbscan, attrscan; Record record;
            int openScan(RecordHandle &recordHandle, constSpace::AttrType attrType, int attrLength, int attrOffset, constSpace::CompOp compOp, void *value);
            if (tbscan.openScan(gl_systemManager->relationHandle, STRING, MAX_RELNAME_LENGTH, OFFSETOF(RelationEntry, relName), EQ_OP, (yyvsp[(3) - (7)].sval)) != 0) {
                cout << "打开关系表" << (yyvsp[(3) - (7)].sval) << "失败\n";
                return -1;
            }
            if (tbscan.getNextRec(record) != 0) {
                cout << "打开关系表" << (yyvsp[(3) - (7)].sval) << "失败\n";
                return -1;
            }
            tbentry = *(RelationEntry*)record.getData();
            attrcount = tbentry.attrCount;
            attrentry = new AttributeEntry[attrcount];
            if (attrscan.openScan(gl_systemManager->attrHandle, STRING, MAX_ATTRNAME_LENGTH, OFFSETOF(AttributeEntry, relName), EQ_OP, (yyvsp[(3) - (7)].sval)) != 0) {
                cout << "打开属性表失败\n";
                return -1; 
            }
            indexcount = 0;
            int primaryKC = 0; // 主键数目
            for (int i = 0; i < attrcount; ++i) {
                if (attrscan.getNextRec(record) != 0) {
                    cout << "缺少属性\n";
                    return -1;
                }
                attrentry[i] = *(AttributeEntry*)record.getData();
                if (attrentry[i].indexNo >= 0) {
                    indexcount++;
                }
                if (attrentry[i].isPrimarykey) {
                    primaryKC++;
                    if (attrentry[i].attrType != AttrType::INT)
                        primaryKC++;
                }
            }
            if (primaryKC == 1 && usePKBufferOptimize) {   // 设置全局优化标志
                usePKOptimize = true;
            } else {
                usePKOptimize = false;
            }
            int BMsize = (attrcount >> 3) + 1;
            int entrysize = tbentry.tupleLength;
            fileHandle = new RecordHandle();
            if (gl_recordManager->openFile((yyvsp[(3) - (7)].sval), *fileHandle) != 0) {
                if (gl_recordManager->createFile((yyvsp[(3) - (7)].sval), BMsize + entrysize) == false) {
                    printf("create %s failed!\n", (yyvsp[(3) - (7)].sval));
                    return -1;
                }
                if (gl_recordManager->openFile((yyvsp[(3) - (7)].sval), *fileHandle) != 0) {
                    printf("open %s failed.\n", (yyvsp[(3) - (7)].sval));
                    return -1;
                }
                cout << "创建文件" << (yyvsp[(3) - (7)].sval) << "成功\n";
            }
            indexHandles = new IX_IndexHandle[indexcount];
            int nowposofhandle = 0;
            for (int i = 0; i < attrcount; ++i) {
                if (attrentry[i].indexNo >= 0) {
                    if (gl_indexingManager->OpenIndex((yyvsp[(3) - (7)].sval), attrentry[i].indexNo, indexHandles[nowposofhandle]) != 0) {
                        cout << "打开索引" << attrentry[i].indexNo << "失败\n";
                        return -1;
                    }
                }
            }
            // 准备好了
            (yyval.sval) = (yyvsp[(3) - (7)].sval);
            if (usePKOptimize) {
                PKBuffer.resetPKBuffer();
            }
            if (gl_qlManager->Insert((yyvsp[(3) - (7)].sval), (yyvsp[(6) - (7)].pnode), &tbentry, attrentry, attrcount, *fileHandle, indexHandles, indexcount) != 0) {
                cout << "插入表" << (yyvsp[(3) - (7)].sval) << "失败\n";
                // return -1;
            }
            insertcount=1;
            tickTock.tick();
        }
    break;

  case 23:
#line 282 "parser/parser.y"
    {   
            // 清空内存
            (yyval.sval) = (yyvsp[(1) - (5)].sval);
            if (gl_qlManager->Insert((yyvsp[(1) - (5)].sval), (yyvsp[(4) - (5)].pnode), &tbentry, attrentry, attrcount, *fileHandle, indexHandles, indexcount) != 0) {
                (yyvsp[(4) - (5)].pnode)->printValueList(cout);
                cout << "插入表" << (yyvsp[(1) - (5)].sval) << "失败\n";
                // return -1;
            }
            insertcount++;
            if (insertcount % 10000 == 0) {
                double second = tickTock.tock();
                cout << "插入" << insertcount << "条,花去时间" << second * 1000 << "ms\n";
            }
            reset_ptr((yyvsp[(1) - (5)].sval)); // 保存tbName 清空其他的
        }
    break;

  case 24:
#line 299 "parser/parser.y"
    {
            // 当前数据库的tbName表的colName建立索引 create index tbName (colName)
            if (gl_systemManager->createIndex((yyvsp[(3) - (6)].sval), (yyvsp[(5) - (6)].sval)) != 0) {
                cout << "创建索引" << (yyvsp[(3) - (6)].sval) << "." << (yyvsp[(5) - (6)].sval) << "失败\n";
            }
        }
    break;

  case 25:
#line 306 "parser/parser.y"
    {
            // 删除索引
            if (gl_systemManager->dropIndex((yyvsp[(3) - (6)].sval), (yyvsp[(5) - (6)].sval)) != 0) {
                cout << "删除索引" << (yyvsp[(3) - (6)].sval) << "." << (yyvsp[(5) - (6)].sval) << "失败\n";
            }
        }
    break;

  case 26:
#line 314 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->init_list((yyvsp[(1) - (1)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 27:
#line 320 "parser/parser.y"
    {
            parser_node *node = allocNode();
            (yyvsp[(1) - (3)].pnode)->append_list((yyvsp[(3) - (3)].pnode), node);
            (yyval.pnode) = (yyvsp[(1) - (3)].pnode);
        }
    break;

  case 28:
#line 327 "parser/parser.y"
    {   
            // 普通域
            parser_node *node = allocNode();
            node->set_field_normal((yyvsp[(1) - (2)].sval), (yyvsp[(2) - (2)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 29:
#line 334 "parser/parser.y"
    {   
            // 非空域
            parser_node *node = allocNode();
            node->set_field_notnull((yyvsp[(1) - (4)].sval), (yyvsp[(2) - (4)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 30:
#line 341 "parser/parser.y"
    {
            // 主键列表
            (yyval.pnode) = (yyvsp[(4) - (5)].pnode);
        }
    break;

  case 31:
#line 346 "parser/parser.y"
    {
            // 外键 
            parser_node *node = allocNode();
            node->set_field_foreign_key((yyvsp[(4) - (10)].sval), (yyvsp[(7) - (10)].sval), (yyvsp[(9) - (10)].sval));
            (yyval.pnode) = node;
        }
    break;

  case 32:
#line 355 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_selector(NULL);
            (yyval.pnode) = node;
        }
    break;

  case 33:
#line 361 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_selector((yyvsp[(1) - (1)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 34:
#line 368 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->init_list((yyvsp[(1) - (1)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 35:
#line 374 "parser/parser.y"
    {
            parser_node *node = allocNode();
            (yyvsp[(1) - (3)].pnode)->append_list((yyvsp[(3) - (3)].pnode), node);
            (yyval.pnode) = (yyvsp[(1) - (3)].pnode);
        }
    break;

  case 36:
#line 382 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->init_string_list((yyvsp[(1) - (1)].sval));
            (yyval.pnode) = node;
        }
    break;

  case 37:
#line 388 "parser/parser.y"
    {
            parser_node *node = allocNode();
            (yyvsp[(1) - (3)].pnode)->append_string_list((yyvsp[(3) - (3)].sval), node);
            (yyval.pnode) = (yyvsp[(1) - (3)].pnode);
        }
    break;

  case 38:
#line 396 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->init_string_list((yyvsp[(1) - (1)].sval));
            (yyval.pnode) = node;
        }
    break;

  case 39:
#line 402 "parser/parser.y"
    {
            parser_node *node = allocNode();
            (yyvsp[(1) - (3)].pnode)->append_string_list((yyvsp[(3) - (3)].sval), node);
            (yyval.pnode) = (yyvsp[(1) - (3)].pnode);
        }
    break;

  case 40:
#line 410 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_attr_type(AttrType::INT, (yyvsp[(3) - (4)].ival));
            (yyval.pnode) = node;
        }
    break;

  case 41:
#line 416 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_attr_type(STRING, (yyvsp[(3) - (4)].ival));
            (yyval.pnode) = node;
        }
    break;

  case 42:
#line 422 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_attr_type(STRING, 10);
            (yyval.pnode) = node;
        }
    break;

  case 43:
#line 428 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_attr_type(FLOAT, 4);
            (yyval.pnode) = node;
        }
    break;

  case 44:
#line 435 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_value((yyvsp[(1) - (1)].ival));
            (yyval.pnode) = node;
        }
    break;

  case 45:
#line 441 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_value((yyvsp[(1) - (1)].sval));
            (yyval.pnode) = node;
        }
    break;

  case 46:
#line 447 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_value((yyvsp[(1) - (1)].fval));
            (yyval.pnode) = node;
        }
    break;

  case 47:
#line 453 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_value();
            (yyval.pnode) = node;
        }
    break;

  case 48:
#line 461 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->init_value_list((yyvsp[(1) - (1)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 49:
#line 467 "parser/parser.y"
    {
            parser_node *node = allocNode();
            (yyvsp[(1) - (3)].pnode)->append_value_list((yyvsp[(3) - (3)].pnode), node);
            (yyval.pnode) = (yyvsp[(1) - (3)].pnode);
        }
    break;

  case 50:
#line 476 "parser/parser.y"
    {
            parser_node *single = allocNode(), *list = allocNode();
            single->single_set((yyvsp[(1) - (3)].sval), (yyvsp[(3) - (3)].pnode));
            list->init_list(single);
            (yyval.pnode) = list;
        }
    break;

  case 51:
#line 483 "parser/parser.y"
    {
            parser_node *single = allocNode(), *list = allocNode();
            single->single_set((yyvsp[(3) - (5)].sval), (yyvsp[(5) - (5)].pnode));
            (yyvsp[(1) - (5)].pnode)->append_list(single, list);
            (yyval.pnode) = (yyvsp[(1) - (5)].pnode);
        }
    break;

  case 52:
#line 492 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->init_list((yyvsp[(1) - (1)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 53:
#line 498 "parser/parser.y"
    {
            parser_node *node = allocNode();
            (yyvsp[(1) - (3)].pnode)->append_list((yyvsp[(3) - (3)].pnode), node);
            (yyval.pnode) = (yyvsp[(1) - (3)].pnode);
        }
    break;

  case 54:
#line 506 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_normal_condition((yyvsp[(1) - (3)].pnode), (yyvsp[(2) - (3)].cval), (yyvsp[(3) - (3)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 55:
#line 512 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_null_cond((yyvsp[(1) - (3)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 56:
#line 518 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_notnull_cond((yyvsp[(1) - (4)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 57:
#line 525 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_col(NULL, (yyvsp[(1) - (1)].sval));
            (yyval.pnode) = node;
        }
    break;

  case 58:
#line 531 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->set_col((yyvsp[(1) - (3)].sval), (yyvsp[(3) - (3)].sval));
            (yyval.pnode) = node;
        }
    break;

  case 59:
#line 538 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->col_or_value((yyvsp[(1) - (1)].pnode), NULL);
            (yyval.pnode) = node;
        }
    break;

  case 60:
#line 544 "parser/parser.y"
    {
            parser_node *node = allocNode();
            node->col_or_value(NULL, (yyvsp[(1) - (1)].pnode));
            (yyval.pnode) = node;
        }
    break;

  case 61:
#line 551 "parser/parser.y"
    {
            (yyval.cval) = LT_OP;
        }
    break;

  case 62:
#line 555 "parser/parser.y"
    {
            (yyval.cval) = LE_OP;
        }
    break;

  case 63:
#line 559 "parser/parser.y"
    {
            (yyval.cval) = GT_OP;
        }
    break;

  case 64:
#line 563 "parser/parser.y"
    {
            (yyval.cval) = GE_OP;
        }
    break;

  case 65:
#line 567 "parser/parser.y"
    {
            (yyval.cval) = EQ_OP;
        }
    break;

  case 66:
#line 571 "parser/parser.y"
    {
            (yyval.cval) = NE_OP;
        }
    break;


/* Line 1267 of yacc.c.  */
#line 2201 "parser/y.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 581 "parser/parser.y"


void yyerror(char *s) {
   // cout << "错误:" << s << endl;
}
int yywrap(void) {
   return 0;
}
void runParser() {
    yydebug = 0;
    while (1) {
        cout << "> " << std::flush;
        yyparse();
        if (exit_flag) 
            break;
        //yyrestart(stdin);
    }
    cout << "\n";
    return;
}
